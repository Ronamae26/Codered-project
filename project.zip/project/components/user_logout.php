<?php
session_start(); // Start session

// Check if the user is logged in
if(isset($_SESSION['token'])){
    // Database connection
    include 'connect.php';

    // Update logout time
    $logout_time = date('Y-m-d H:i:s');
    $token = $_SESSION['token'];

    $update_logout_time = $conn->prepare("UPDATE login_logs SET logout_datetime = ? WHERE token = ?");
    $update_logout_time->execute([$logout_time, $token]);

    // Clear session and cookies
    session_unset();
    session_destroy();
    setcookie('user_id', '', time() - 3600, '/'); // Remove the user_id cookie

    // Redirect to the login page or any other desired location
    header('location:../login.php');
    exit();
} else {
    // Redirect to the login page if the user is not logged in
    header('location:../login.php');
    exit();
}
?>

<?php

   // include 'connect.php';

   // setcookie('user_id', '', time() - 1, '/');

   // header('location:../login.php');

?>