<?php

include '../components/connect.php';

if(isset($_COOKIE['tutor_id'])){
   $tutor_id = $_COOKIE['tutor_id'];
}else{
   $tutor_id = '';
   header('location:login.php');
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Dashboard</title>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
   <link rel="stylesheet" href="../css/admin_style.css">
   <link rel="stylesheet" href="https://cdn.datatables.net/2.0.5/css/dataTables.dataTables.css">
   <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
   <script src="https://cdn.datatables.net/2.0.5/js/dataTables.js"></script>
   <style>
      .login-history-table {
          width: 100%;
          border-collapse: collapse;
      }

      .login-history-table th {
          background-color: #f8f9fa;
          border: 1px solid #dee2e6; 
          padding: 8px;
          text-align: left;
      }

      .login-history-table td {
          border: 1px solid #dee2e6;
          padding: 8px;
      }

      .login-history-table tbody tr:nth-child(even) {
          background-color: #f8f9fa;
      }

      .login-history-table .empty {
          text-align: center;
          padding: 10px;
          color: #6c757d;
      }

      .login-history-table th,
      .login-history-table td {
          font-size: 16px;
      }

      .search-input {
          margin-bottom: 10px;
          padding: 8px;
          width: 100%;
          box-sizing: border-box;
          border: 1px solid #ced4da;
          border-radius: 4px;
          font-size: 16px;
      }

      .match {
          background-color: yellow;
      }

   </style>
</head>
<body>

<?php include '../components/admin_header.php'; ?>
   
<section class="contents">
   <h1 class="heading">User log history</h1>
   <table id="example" class="display login-history-table" style="width:100%">
      <thead>
         <tr>
            <th>#</th>
            <th>SR-Code</th>
            <th>User Name</th>
            <th>Login Time</th>
            <th>Logout Time</th>
            <th>Elapse time</th>
         </tr>
      </thead>
      <tbody>
         <?php
            $i = 1;
            $select_logs = $conn->query("SELECT * FROM login_logs JOIN users ON login_logs.user_id = users.id ORDER BY login_logs.login_time DESC");
               while($fetch_log = $select_logs->fetch(PDO::FETCH_ASSOC)){
                   $login_time = strtotime($fetch_log['login_time']);
                   $logout_time = strtotime($fetch_log['logout_datetime']);
                   $elapsed_time = $logout_time - $login_time;
                   $formatted_elapsed_time = gmdate("H:i:s", $elapsed_time);
         ?>
         <tr>
            <td><?= $i++ ?></td>
            <td><?= $fetch_log['sr_code']; ?></td>
            <td><?= ucwords($fetch_log['name']); ?></td>
            <td><?= $fetch_log['login_time']; ?></td>
            <td><?= $fetch_log['logout_datetime'] !== NULL ? $fetch_log['logout_datetime'] : "Ongoing Session"; ?></td>
            <td><?= $formatted_elapsed_time ?></td>
         </tr>
         <?php
               }
            
         ?>
      </tbody>
   </table>

</section>


<script src="../js/admin_script.js"></script>
<script>
   new DataTable('#example', {
    layout: {
        bottomEnd: {
            paging: {
                boundaryNumbers: false
            }
        }
    }
});
</script>
</body>
</html>