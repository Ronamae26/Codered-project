<?php

include '../components/connect.php';

if(isset($_COOKIE['tutor_id'])){
   $tutor_id = $_COOKIE['tutor_id'];
}else{
   $tutor_id = '';
   header('location:login.php');
}

if(isset($_GET['get_id'])){
   $get_id = $_GET['get_id'];
}else{
   $get_id = '';
   header('location:dashboard.php');
}

if(isset($_POST['update'])){

   $file_id = $_POST['file_id'];
   $file_id= filter_var($file_id, FILTER_SANITIZE_STRING);
   $status = $_POST['status'];
   $status = filter_var($status, FILTER_SANITIZE_STRING);
   $title = $_POST['title'];
   $title = filter_var($title, FILTER_SANITIZE_STRING);
   $description = $_POST['description'];
   $description = filter_var($description, FILTER_SANITIZE_STRING);
   $course = $_POST['course'];
   $course = filter_var($course, FILTER_SANITIZE_STRING);

   $update_content = $conn->prepare("UPDATE `content` SET title = ?, description = ?, status = ?, course_id = ? WHERE id = ?");
   $update_content->execute([$title, $description, $status, $course, $file_id]);

   $old_thumb = $_POST['old_thumb'];
   $old_thumb = filter_var($old_thumb, FILTER_SANITIZE_STRING);
   $thumb = isset($_FILES['thumb']) && isset($_FILES['thumb']['name']) ? $_FILES['thumb']['name'] : null;
   $thumb_tmp_name = isset($_FILES['thumb']['tmp_name']) ? $_FILES['thumb']['tmp_name'] : null;

   if(isset($thumb) && !empty($thumb)) {
      $thumb_ext = pathinfo($thumb, PATHINFO_EXTENSION);
      $rename_thumb = uniqid('', true).'.'.$thumb_ext; 
      $thumb_folder = '../uploaded_files/'.$rename_thumb;
      
      if(move_uploaded_file($thumb_tmp_name, $thumb_folder)) {
         $update_thumb = $conn->prepare("UPDATE `content` SET thumb = ? WHERE id = ?");
         $update_thumb->execute([$rename_thumb, $file_id]); 
         if($old_thumb != '' AND $old_thumb != $rename_thumb){
            unlink('../uploaded_files/'.$old_thumb);
         }
      } else {
         $message[] = 'Failed to upload thumbnail.';
      }
   }

   $file = isset($_FILES['new_file']) && isset($_FILES['new_file']['name']) ? $_FILES['new_file']['name'] : null;
   $file_tmp_name = isset($_FILES['new_file']['tmp_name']) ? $_FILES['new_file']['tmp_name'] : null;

   if(isset($file) && !empty($file)) {
      $file_ext = pathinfo($file, PATHINFO_EXTENSION);
      $rename_file = uniqid().'.'.$file_ext;
      $file_folder = '../uploaded_files/'.$rename_file;
      
      if(move_uploaded_file($file_tmp_name, $file_folder)) {
         $update_file = $conn->prepare("UPDATE `content` SET file = ? WHERE id = ?");
         $update_file->execute([$rename_file, $file_id]);
         $old_file = $_POST['old_file'];
         $old_file = filter_var($old_file, FILTER_SANITIZE_STRING);
         if($old_file != '' AND $old_file != $rename_file){
            unlink('../uploaded_files/'.$old_file);
         }
      } else {
         $message[] = 'Failed to upload file.';
      }
   }

}

if(isset($_POST['delete_file'])){

   $delete_id = $_POST['file_id'];
   $delete_id = filter_var($delete_id, FILTER_SANITIZE_STRING);

   $delete_thumb = $conn->prepare("SELECT thumb FROM `content` WHERE id = ? LIMIT 1");
   $delete_thumb->execute([$delete_id]);
   $fetch_thumb = $delete_thumb->fetch(PDO::FETCH_ASSOC);
   unlink('../uploaded_files/'.$fetch_thumb['thumb']);

   $delete_file = $conn->prepare("SELECT file FROM `content` WHERE id = ? LIMIT 1");
   $delete_file->execute([$delete_id]);
   $fetch_file = $delete_file->fetch(PDO::FETCH_ASSOC);
   unlink('../uploaded_files/'.$fetch_file['file']);

   $delete_likes = $conn->prepare("DELETE FROM `likes` WHERE content_id = ?");
   $delete_likes->execute([$delete_id]);
   $delete_comments = $conn->prepare("DELETE FROM `comments` WHERE content_id = ?");
   $delete_comments->execute([$delete_id]);

   $delete_content = $conn->prepare("DELETE FROM `content` WHERE id = ?");
   $delete_content->execute([$delete_id]);
   header('location:contents.php');
    
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Update Content</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="../css/admin_style.css">

</head>
<body>

<?php include '../components/admin_header.php'; ?>
   
<section class="video-form">

   <h1 class="heading">Update Content</h1>

   <?php
      $select_files = $conn->prepare("SELECT * FROM `content` WHERE id = ? AND tutor_id = ?");
      $select_files->execute([$get_id, $tutor_id]);
      if($select_files->rowCount() > 0){
         while($fecth_files = $select_files->fetch(PDO::FETCH_ASSOC)){ 
            $file_id = $fecth_files['id'];
   ?>
   <form action="" method="post" enctype="multipart/form-data">
      <input type="hidden" name="file_id" value="<?= $fecth_files['id']; ?>">
      <input type="hidden" name="old_thumb" value="<?= $fecth_files['thumb']; ?>">
      <input type="hidden" name="old_file" value="<?= $fecth_files['file']; ?>">
      <p>Update Status <span>*</span></p>
      <select name="status" class="box" required>
         <option value="<?= $fecth_files['status']; ?>" selected><?= $fecth_files['status']; ?></option>
         <option value="active">Active</option>
         <option value="deactive">Deactive</option>
      </select>
      <p>Update Title <span>*</span></p>
      <input type="text" name="title" maxlength="100" required placeholder="Enter file title" class="box" value="<?= $fecth_files['title']; ?>">
      <p>Update Description <span>*</span></p>
      <textarea name="description" class="box" required placeholder="Write description" maxlength="1000" cols="30" rows="10"><?= $fecth_files['description']; ?></textarea>
      <p>Update course</p>
      <select name="course" class="box">
         <option value="<?= $fecth_files['course_id']; ?>" selected>--Select course</option>
         <?php
         $select_courses = $conn->prepare("SELECT * FROM `course` WHERE tutor_id = ?");
         $select_courses->execute([$tutor_id]);
         if($select_courses->rowCount() > 0){
            while($fetch_course = $select_courses->fetch(PDO::FETCH_ASSOC)){
         ?>
         <option value="<?= $fetch_course['id']; ?>"><?= $fetch_course['title']; ?></option>
         <?php
            }
         ?>
         <?php
         }else{
            echo '<option value="" disabled>No course created yet!</option>';
         }
         ?>
      </select>
      <img src="../uploaded_files/<?= $fecth_files['thumb']; ?>" alt="">
      <p>Update Thumbnail</p>
      <input type="file" name="thumb" accept="image/*" class="box">
      <?php if(isset($fecth_files['file']) && $fecth_files['file'] != ''){ ?>
      <p>Current File:</p>
      <?php 
         if (pathinfo($fecth_files['file'], PATHINFO_EXTENSION) === 'pdf') {
      ?>
      <embed src="../uploaded_files/<?= $fecth_files['file']; ?>" type="application/pdf" width="100%" height="600px" />
      <?php 
         } else {
      ?>
      <video src="../uploaded_files/<?= $fecth_files['file']; ?>" controls></video>
      <?php 
         }
      ?>
      <?php } ?>

      <p>Upload New File (PDF or Video)</p>
      <input type="file" name="new_file" accept="application/pdf, video/*" class="box">
      <input type="submit" value="Update Content" name="update" class="btn">
      <div class="flex-btn">
         <a href="view_content.php?get_id=<?= $file_id; ?>" class="option-btn">View Content</a>
         <input type="submit" value="Delete Content" name="delete_file" class="delete-btn">
      </div>
   </form>
   <?php
         }
      }else{
         echo '<p class="empty">File not found! <a href="add_content.php" class="btn" style="margin-top: 1.5rem;">Add Files</a></p>';
      }
   ?>

</section>

<script src="../js/admin_script.js"></script>

</body>
</html>