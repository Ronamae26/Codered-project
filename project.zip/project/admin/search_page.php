<?php

include '../components/connect.php';

if(isset($_COOKIE['tutor_id'])){
   $tutor_id = $_COOKIE['tutor_id'];
}else{
   $tutor_id = '';
   header('location:login.php');
}

if(isset($_POST['delete_file'])){
   $delete_id = $_POST['file_id'];
   $delete_id = filter_var($delete_id, FILTER_SANITIZE_STRING);
   $verify_file = $conn->prepare("SELECT * FROM `content` WHERE id = ? LIMIT 1");
   $verify_file->execute([$delete_id]);
   if($verify_file->rowCount() > 0){
      $delete_file_thumb = $conn->prepare("SELECT * FROM `content` WHERE id = ? LIMIT 1");
      $delete_file_thumb->execute([$delete_id]);
      $fetch_thumb = $delete_file_thumb->fetch(PDO::FETCH_ASSOC);
      unlink('../uploaded_files/'.$fetch_thumb['thumb']);
      $delete_file = $conn->prepare("SELECT * FROM `content` WHERE id = ? LIMIT 1");
      $delete_file->execute([$delete_id]);
      $fetch_file = $delete_file->fetch(PDO::FETCH_ASSOC);
      unlink('../uploaded_files/'.$fetch_file['file']);
      $delete_likes = $conn->prepare("DELETE FROM `likes` WHERE content_id = ?");
      $delete_likes->execute([$delete_id]);
      $delete_comments = $conn->prepare("DELETE FROM `comments` WHERE content_id = ?");
      $delete_comments->execute([$delete_id]);
      $delete_content = $conn->prepare("DELETE FROM `content` WHERE id = ?");
      $delete_content->execute([$delete_id]);
      $message[] = 'file deleted!';
   }else{
      $message[] = 'file already deleted!';
   }

}

if(isset($_POST['delete_course'])){
   $delete_id = $_POST['course_id'];
   $delete_id = filter_var($delete_id, FILTER_SANITIZE_STRING);

   $verify_course = $conn->prepare("SELECT * FROM `course` WHERE id = ? AND tutor_id = ? LIMIT 1");
   $verify_course->execute([$delete_id, $tutor_id]);

   if($verify_course->rowCount() > 0){

   

   $delete_course_thumb = $conn->prepare("SELECT * FROM `course` WHERE id = ? LIMIT 1");
   $delete_course_thumb->execute([$delete_id]);
   $fetch_thumb = $delete_course_thumb->fetch(PDO::FETCH_ASSOC);
   unlink('../uploaded_files/'.$fetch_thumb['thumb']);
   $delete_bookmark = $conn->prepare("DELETE FROM `bookmark` WHEREcourse_id = ?");
   $delete_bookmark->execute([$delete_id]);
   $delete_course = $conn->prepare("DELETE FROM `course` WHERE id = ?");
   $delete_course->execute([$delete_id]);
   $message[] = 'course deleted!';
   }else{
      $message[] = 'course already deleted!';
   }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Dashboard</title>

   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

   <link rel="stylesheet" href="../css/admin_style.css">

</head>
<body>

<?php include '../components/admin_header.php'; ?>
   
<section class="contents">

   <h1 class="heading">contents</h1>

   <div class="box-container">

   <?php
      if(isset($_POST['search']) or isset($_POST['search_btn'])){
      $search = $_POST['search'];
      $select_files = $conn->prepare("SELECT * FROM `content` WHERE title LIKE '%{$search}%' AND tutor_id = ? ORDER BY date DESC");
      $select_files->execute([$tutor_id]);
      if($select_files->rowCount() > 0){
         while($fecth_files = $select_files->fetch(PDO::FETCH_ASSOC)){ 
            $file_id = $fecth_files['id'];
   ?>
      <div class="box">
         <div class="flex">
            <div><i class="fas fa-dot-circle" style="<?php if($fecth_files['status'] == 'active'){echo 'color:limegreen'; }else{echo 'color:red';} ?>"></i><span style="<?php if($fecth_files['status'] == 'active'){echo 'color:limegreen'; }else{echo 'color:red';} ?>"><?= $fecth_files['status']; ?></span></div>
            <div><i class="fas fa-calendar"></i><span><?= $fecth_files['date']; ?></span></div>
         </div>
         <img src="../uploaded_files/<?= $fecth_files['thumb']; ?>" class="thumb" alt="">
         <h3 class="title"><?= $fecth_files['title']; ?></h3>
         <form action="" method="post" class="flex-btn">
            <input type="hidden" name="file_id" value="<?= $file_id; ?>">
            <a href="update_content.php?get_id=<?= $file_id; ?>" class="option-btn">update</a>
            <input type="submit" value="delete" class="delete-btn" onclick="return confirm('delete this file?');" name="delete_file">
         </form>
         <a href="view_content.php?get_id=<?= $file_id; ?>" class="btn">view content</a>
      </div>
   <?php
         }
      }else{
         echo '<p class="empty">no contents founds!</p>';
      }
   }else{
      echo '<p class="empty">please search something!</p>';
   }
   ?>

   </div>

</section>

<section class="playlists">

   <h1 class="heading">courses</h1>

   <div class="box-container">
   
      <?php
      if(isset($_POST['search']) or isset($_POST['search_btn'])){
         $search = $_POST['search'];
         $select_course = $conn->prepare("SELECT * FROM `course` WHERE title LIKE '%{$search}%' AND tutor_id = ? ORDER BY date DESC");
         $select_course->execute([$tutor_id]);
         if($select_course->rowCount() > 0){
         while($fetch_course = $select_course->fetch(PDO::FETCH_ASSOC)){
            $course_id = $fetch_course['id'];
            $count_files = $conn->prepare("SELECT * FROM `content` WHERE course_id = ?");
            $count_files->execute([$course_id]);
            $total_files = $count_files->rowCount();
      ?>
      <div class="box">
         <div class="flex">
            <div><i class="fas fa-circle-dot" style="<?php if($fetch_course['status'] == 'active'){echo 'color:limegreen'; }else{echo 'color:red';} ?>"></i><span style="<?php if($fetch_course['status'] == 'active'){echo 'color:limegreen'; }else{echo 'color:red';} ?>"><?= $fetch_course['status']; ?></span></div>
            <div><i class="fas fa-calendar"></i><span><?= $fetch_course['date']; ?></span></div>
         </div>
         <div class="thumb">
            <span><?= $total_files; ?></span>
            <img src="../uploaded_files/<?= $fetch_course['thumb']; ?>" alt="">
         </div>
         <h3 class="title"><?= $fetch_course['title']; ?></h3>
         <p class="description"><?= $fetch_course['description']; ?></p>
         <form action="" method="post" class="flex-btn">
            <input type="hidden" name="course_id" value="<?= $course_id; ?>">
            <a href="update_course.php?get_id=<?= $course_id; ?>" class="option-btn">update</a>
            <input type="submit" value="delete course" class="delete-btn" onclick="return confirm('delete this course?');" name="delete">
         </form>
         <a href="view_course.php?get_id=<?= $course_id; ?>" class="btn">view course</a>
      </div>
      <?php
         } 
      }else{
         echo '<p class="empty">no courses found!</p>';
      }}else{
         echo '<p class="empty">please search something!</p>';
      }
      ?>

   </div>

</section>

<script src="../js/admin_script.js"></script>

<script>
   document.querySelectorAll('.playlists .box-container .box .description').forEach(content => {
      if(content.innerHTML.length > 100) content.innerHTML = content.innerHTML.slice(0, 100);
   });
</script>

</body>
</html>