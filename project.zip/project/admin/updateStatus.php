<?php

include '../components/connect.php';

if(isset($_GET['id']) && isset($_GET['type'])){
   $id = $_GET['id'];
   $type = $_GET['type'];
   $value = "";
   if($type == "Approve") {
      $value = 1;
   } else {
      $value = 2;
   }
   $update_course = $conn->prepare("UPDATE `schedule_list` SET status = ? WHERE id = ?");
   $update_course->execute([$value, $id]);
   header('location:appointments.php');
}else{
   $tutor_id = '';
   header('location:appointments.php');
}


?>
