<?php

include '../components/connect.php';

if(isset($_COOKIE['tutor_id'])){
   $tutor_id = $_COOKIE['tutor_id'];
}else{
   $tutor_id = '';
   header('location:login.php');
}

if(isset($_GET['get_id'])){
   $get_id = $_GET['get_id'];
   $select_course = $conn->prepare("SELECT * FROM `course` WHERE id = ? AND tutor_id = ?");
   $select_course->execute([$get_id, $tutor_id]);
   if(!$select_course->rowCount()) {
      header('location:dashboard.php');
   }
}else{
   $get_id = '';
   header('location:dashboard.php');
}

if(isset($_POST['update'])){

   $file_id = $_POST['file_id'];
   $file_id = filter_var($file_id, FILTER_SANITIZE_STRING);
   $status = $_POST['status'];
   $status = filter_var($status, FILTER_SANITIZE_STRING);
   $title = $_POST['title'];
   $title = filter_var($title, FILTER_SANITIZE_STRING);
   $description = $_POST['description'];
   $description = filter_var($description, FILTER_SANITIZE_STRING);
   $course = $_POST['course'];
   $course = filter_var($course, FILTER_SANITIZE_STRING);

   $update_content = $conn->prepare("UPDATE `content` SET title = ?, description = ?, status = ? WHERE id = ?");
   $update_content->execute([$title, $description, $status, $file_id]);

   if(!empty($course)){
      $update_course = $conn->prepare("UPDATE `content` SET course_id = ? WHERE id = ?");
      $update_course->execute([$course, $file_id]);
   }

   $old_thumb = $_POST['old_thumb'];
   $old_thumb = filter_var($old_thumb, FILTER_SANITIZE_STRING);
   $thumb = isset($_FILES['thumb']['name']) ? $_FILES['thumb']['name'] : null;
   $thumb_tmp_name = isset($_FILES['thumb']['tmp_name']) ? $_FILES['thumb']['tmp_name'] : null;

   if(isset($thumb) && !empty($thumb)) {
      $thumb_ext = pathinfo($thumb, PATHINFO_EXTENSION);
      $rename_thumb = unique_id().'.'.$thumb_ext;
      $thumb_folder = '../uploaded_files/'.$rename_thumb;
      
      if(move_uploaded_file($thumb_tmp_name, $thumb_folder)) {
         $update_thumb = $conn->prepare("UPDATE `content` SET thumb = ? WHERE id = ?");
         $update_thumb->execute([$rename_thumb, $file_id]);
         if($old_thumb != '' AND $old_thumb != $rename_thumb){
            unlink('../uploaded_files/'.$old_thumb);
         }
      } else {
         $message[] = 'Failed to upload thumbnail.';
      }
   }

   $old_file = isset($_POST['old_file']) ? $_POST['old_file'] : null;
   $new_file = isset($_FILES['new_file']['name']) ? $_FILES['new_file']['name'] : null;
   $file_tmp_name = isset($_FILES['new_file']['tmp_name']) ? $_FILES['new_file']['tmp_name'] : null;

   if(isset($new_file) && !empty($new_file)) {
      $file_ext = pathinfo($new_file, PATHINFO_EXTENSION);
      $rename_file = unique_id().'.'.$file_ext;
      $file_folder = '../uploaded_files/'.$rename_file;

      if(move_uploaded_file($file_tmp_name, $file_folder)) {
         $update_file = $conn->prepare("UPDATE `content` SET file = ? WHERE id = ?");
         $update_file->execute([$rename_file, $file_id]);
         if($old_file != '' AND $old_file != $rename_file){
            unlink('../uploaded_files/'.$old_file);
         }
      } else {
         $message[] = 'Failed to upload file.';
      }
   }

   $message[] = 'Content updated!';

}

if(isset($_POST['delete_file'])){

   $delete_id = $_POST['file_id'];
   $delete_id = filter_var($delete_id, FILTER_SANITIZE_STRING);

   $delete_thumb = $conn->prepare("SELECT thumb FROM `content` WHERE id = ? LIMIT 1");
   $delete_thumb->execute([$delete_id]);
   $fetch_thumb = $delete_thumb->fetch(PDO::FETCH_ASSOC);
   unlink('../uploaded_files/'.$fetch_thumb['thumb']);

   $delete_file = $conn->prepare("SELECT file FROM `content` WHERE id = ? LIMIT 1");
   $delete_file->execute([$delete_id]);
   $fetch_file = $delete_file->fetch(PDO::FETCH_ASSOC);
   unlink('../uploaded_files/'.$fetch_file['file']);

   $delete_likes = $conn->prepare("DELETE FROM `likes` WHERE content_id = ?");
   $delete_likes->execute([$delete_id]);
   $delete_comments = $conn->prepare("DELETE FROM `comments` WHERE content_id = ?");
   $delete_comments->execute([$delete_id]);

   $delete_content = $conn->prepare("DELETE FROM `content` WHERE id = ?");
   $delete_content->execute([$delete_id]);
   header('location:contents.php');
    
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Course Details</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="../css/admin_style.css">

</head>
<body>

<?php include '../components/admin_header.php'; ?>
   
<section class="playlist-details">

   <h1 class="heading">course details</h1>

   <?php
      $select_course = $conn->prepare("SELECT * FROM `course` WHERE id = ? AND tutor_id = ?");
      $select_course->execute([$get_id, $tutor_id]);
      if($select_course->rowCount() > 0){
         while($fetch_course = $select_course->fetch(PDO::FETCH_ASSOC)){
            $course_id = $fetch_course['id'];
            $count_files = $conn->prepare("SELECT * FROM `content` WHERE course_id = ?");
            $count_files->execute([$course_id]);
            $total_files = $count_files->rowCount();
   ?>
   <div class="row">
      <div class="thumb">
         <span><?= $total_files; ?></span>
         <img src="../uploaded_files/<?= $fetch_course['thumb']; ?>" alt="">
      </div>
      <div class="details">
         <h3 class="title"><?= $fetch_course['title']; ?></h3>
         <div class="date"><i class="fas fa-calendar"></i><span><?= $fetch_course['date']; ?></span></div>
         <div class="description"><?= $fetch_course['description']; ?></div>
         <form action="" method="post" class="flex-btn">
            <input type="hidden" name="course_id" value="<?= $course_id; ?>">
            <a href="update_course.php?get_id=<?= $course_id; ?>" class="option-btn">update course</a>
            <input type="submit" value="delete course" class="delete-btn" onclick="return confirm('delete this course?');" name="delete">
         </form>
      </div>
   </div>
   <?php
         }
      }else{
         echo '<p class="empty">no course found!</p>';
      }
   ?>

</section>

<section class="contents">

   <h1 class="heading">file</h1>

   <div class="box-container">

   <?php
      $select_files = $conn->prepare("SELECT * FROM `content` WHERE tutor_id = ? AND course_id = ?");
      $select_files->execute([$tutor_id, $course_id]);
      if($select_files->rowCount() > 0){
         while($fecth_files = $select_files->fetch(PDO::FETCH_ASSOC)){ 
            $files_id = $fecth_files['id'];
   ?>
      <div class="box">
         <div class="flex">
            <div><i class="fas fa-dot-circle" style="<?php if($fecth_files['status'] == 'active'){echo 'color:limegreen'; }else{echo 'color:red';} ?>"></i><span style="<?php if($fecth_files['status'] == 'active'){echo 'color:limegreen'; }else{echo 'color:red';} ?>"><?= $fecth_files['status']; ?></span></div>
            <div><i class="fas fa-calendar"></i><span><?= $fecth_files['date']; ?></span></div>
         </div>
         <img src="../uploaded_files/<?= $fecth_files['thumb']; ?>" class="thumb" alt="">
         <h3 class="title"><?= $fecth_files['title']; ?></h3>
         <form action="" method="post" class="flex-btn">
            <input type="hidden" name="file_id" value="<?= $files_id; ?>"> <!-- Change $file_id to $files_id -->
            <a href="update_content.php?get_id=<?= $files_id; ?>" class="option-btn">update</a> <!-- Change $file_id to $files_id -->
            <input type="submit" value="delete" class="delete-btn" onclick="return confirm('delete this file?');" name="delete_file">
         </form>
         <a href="view_content.php?get_id=<?= $files_id; ?>" class="btn">view content</a> <!-- Change $file_id to $files_id -->
      </div>
   <?php
         }
      }else{
         echo '<p class="empty">no files added yet! <a href="add_content.php" class="btn" style="margin-top: 1.5rem;">add file</a></p>';
      }
   ?>

   </div>

</section>


<script src="../js/admin_script.js"></script>

</body>
</html>