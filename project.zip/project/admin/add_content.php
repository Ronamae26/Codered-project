<?php

include '../components/connect.php';

if(isset($_COOKIE['tutor_id'])){
   $tutor_id = $_COOKIE['tutor_id'];
}else{
   $tutor_id = '';
   header('location:login.php');
}

if(isset($_POST['submit'])){

   $id = uniqid();
   $status = $_POST['status'];
   $status = filter_var($status, FILTER_SANITIZE_STRING);
   $title = $_POST['title'];
   $title = filter_var($title, FILTER_SANITIZE_STRING);
   $description = $_POST['description'];
   $description = filter_var($description, FILTER_SANITIZE_STRING);
   $course = $_POST['course'];
   $course = filter_var($course, FILTER_SANITIZE_STRING);

   $thumb = $_FILES['thumb']['name'];
   $thumb = filter_var($thumb, FILTER_SANITIZE_STRING);
   $thumb_ext = pathinfo($thumb, PATHINFO_EXTENSION);
   $rename_thumb = uniqid().'.'.$thumb_ext;
   $thumb_size = $_FILES['thumb']['size'];
   $thumb_tmp_name = $_FILES['thumb']['tmp_name'];
   $thumb_folder = '../uploaded_files/'.$rename_thumb;

   $file = $_FILES['file']['name'];
   $file = filter_var($file, FILTER_SANITIZE_STRING);
   $file_ext = pathinfo($file, PATHINFO_EXTENSION);
   $rename_file = uniqid().'.'.$file_ext; // Change $rename_video to $rename_file
   $file_tmp_name = $_FILES['file']['tmp_name'];
   $file_folder = '../uploaded_files/'.$rename_file;

   if($thumb_size > 2000000){
      $message[] = 'image size is too large!';
   }else{
      $add_content = $conn->prepare("INSERT INTO `content` (id, tutor_id, course_id, title, description, file, thumb, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
      $add_content->execute([$id, $tutor_id, $course, $title, $description, $rename_file, $rename_thumb, $status]);
      move_uploaded_file($thumb_tmp_name, $thumb_folder);
      move_uploaded_file($file_tmp_name, $file_folder);
      $message[] = 'new content uploaded!';
   }

}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Dashboard</title>

   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">


   <link rel="stylesheet" href="../css/admin_style.css">

</head>
<body>

<?php include '../components/admin_header.php'; ?>
   
<section class="video-form">

   <h1 class="heading">upload content</h1>

   <form action="" method="post" enctype="multipart/form-data">
   <p>file status <span>*</span></p>
   <select name="status" class="box" required>
      <option value="" selected disabled>-- select status</option>
      <option value="active">active</option>
      <option value="deactive">deactive</option>
   </select>
   <p>file title <span>*</span></p>
   <input type="text" name="title" maxlength="100" required placeholder="enter file title" class="box">
   <p>file description <span>*</span></p>
   <textarea name="description" class="box" required placeholder="write description" maxlength="1000" cols="30" rows="10"></textarea>
   <p>file folder <span>*</span></p>
   <select name="course" class="box" required>
      <option value="" disabled selected>--select folder</option>
      <?php
      $select_courses = $conn->prepare("SELECT * FROM `course` WHERE tutor_id = ?");
      $select_courses->execute([$tutor_id]);
      if($select_courses->rowCount() > 0){
         while($fetch_course = $select_courses->fetch(PDO::FETCH_ASSOC)){
      ?>
      <option value="<?= $fetch_course['id']; ?>"><?= $fetch_course['title']; ?></option>
      <?php
         }
      ?>
      <?php
      }else{
         echo '<option value="" disabled>no course created yet!</option>';
      }
      ?>
   </select>
   <p>select thumbnail <span>*</span></p>
   <input type="file" name="thumb" accept="image/*" required class="box">
   <p>select file <span>*</span></p>
   <input type="file" name="file" accept=".pdf, .mp4, .avi, .mov, .wmv" required class="box">
   <input type="submit" value="upload file" name="submit" class="btn"> <!-- Change name to "submit" -->
</form>

</section>

<script src="../js/admin_script.js"></script>

</body>
</html>
