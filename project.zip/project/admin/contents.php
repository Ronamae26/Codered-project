<?php

include '../components/connect.php';

if(isset($_COOKIE['tutor_id'])){
   $tutor_id = $_COOKIE['tutor_id'];
}else{
   $tutor_id = '';
   header('location:login.php');
}

if(isset($_POST['delete_file'])){
   $delete_id = $_POST['file_id'];
   $delete_id = filter_var($delete_id, FILTER_SANITIZE_STRING);
   $verify_file = $conn->prepare("SELECT * FROM `content` WHERE id = ? LIMIT 1");
   $verify_file->execute([$delete_id]);
   if($verify_file->rowCount() > 0){
      $delete_file_thumb = $conn->prepare("SELECT * FROM `content` WHERE id = ? LIMIT 1");
      $delete_file_thumb->execute([$delete_id]);
      $fetch_thumb = $delete_file_thumb->fetch(PDO::FETCH_ASSOC);
      unlink('../uploaded_files/'.$fetch_thumb['thumb']);
      $delete_file = $conn->prepare("SELECT * FROM `content` WHERE id = ? LIMIT 1");
      $delete_file->execute([$delete_id]);
      $fetch_file = $delete_file->fetch(PDO::FETCH_ASSOC);
      unlink('../uploaded_files/'.$fetch_file['file']);
      $delete_likes = $conn->prepare("DELETE FROM `likes` WHERE content_id = ?");
      $delete_likes->execute([$delete_id]);
      $delete_comments = $conn->prepare("DELETE FROM `comments` WHERE content_id = ?");
      $delete_comments->execute([$delete_id]);
      $delete_content = $conn->prepare("DELETE FROM `content` WHERE id = ?");
      $delete_content->execute([$delete_id]);
      $message[] = 'file deleted!';
   }else{
      $message[] = 'file already deleted!';
   }

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Dashboard</title>

   
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

 
   <link rel="stylesheet" href="../css/admin_style.css">

</head>
<body>

<?php include '../components/admin_header.php'; ?>
   
<section class="contents">

   <h1 class="heading">your contents</h1>

   <div class="box-container">

   <div class="box" style="text-align: center;">
      <h3 class="title" style="margin-bottom: .5rem;">create new content</h3>
      <a href="add_content.php" class="btn">add content</a>
   </div>

   <?php
      $select_files = $conn->prepare("SELECT * FROM `content` WHERE tutor_id = ? ORDER BY date DESC");
      $select_files->execute([$tutor_id]);
      if($select_files->rowCount() > 0){
         while ($fetch_files = $select_files->fetch(PDO::FETCH_ASSOC)) {
            $file_id = $fetch_files['id'];
            $thumb_path = '../uploaded_files/' . $fetch_files['thumb'];
      ?>
      <div class="box">
         <div class="flex">
            <div><i class="fas fa-dot-circle" style="<?php if($fetch_files['status'] == 'active'){echo 'color:limegreen'; }else{echo 'color:red';} ?>"></i><span style="<?php if($fetch_files['status'] == 'active'){echo 'color:limegreen'; }else{echo 'color:red';} ?>"><?= $fetch_files['status']; ?></span></div>
            <div><i class="fas fa-calendar"></i><span><?= $fetch_files['date']; ?></span></div>
         </div>
         <img src="<?= $thumb_path ?>" class="thumb" alt="">
         <h3 class="title"><?= $fetch_files['title']; ?></h3>
         <form action="" method="post" class="flex-btn">
            <input type="hidden" name="file_id" value="<?= $file_id; ?>">
            <a href="update_content.php?get_id=<?= $file_id; ?>" class="option-btn">update</a>
            <input type="submit" value="delete" class="delete-btn" onclick="return confirm('delete this file?');" name="delete_file">
         </form>
         <a href="view_content.php?get_id=<?= $file_id; ?>" class="btn">view content</a>
      </div>
      <?php
         }
      }else{
         echo '<p class="empty">no contents added yet!</p>';
      }
      ?>

   </div>

</section>


<script src="../js/admin_script.js"></script>

</body>
</html>