-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 03, 2024 at 05:53 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `adms_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookmark`
--

CREATE TABLE `bookmark` (
  `user_id` varchar(20) NOT NULL,
  `course_id` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bookmark`
--

INSERT INTO `bookmark` (`user_id`, `course_id`) VALUES
('662da085f420d', '662d9f22ebcfe'),
('6633', '6633b8ded58dc'),
('6633', '66344e70a236e'),
('6633', '6634552e854c2');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` varchar(20) NOT NULL,
  `content_id` varchar(20) NOT NULL,
  `user_id` varchar(20) NOT NULL,
  `tutor_id` varchar(20) NOT NULL,
  `comment` varchar(1000) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `content_id`, `user_id`, `tutor_id`, `comment`, `date`) VALUES
('6633d192bff79', '6633d160a7a9e', '6633', '6633', 'pangit mo ', '2024-05-03'),
('66344f552c039', '662da86a8e2e6', '6633', 'nXsh5IHnMeP1XTq2sSm1', '123123', '2024-05-03'),
('663452d75cc20', '663452b8c0d0d', '6633', '6633', 'yess po', '2024-05-03'),
('663455afeda86', '6634557ea9efd', '6633', '662', 'hello po', '2024-05-03'),
('66345605dbb00', '663455edad6ad', '6633', '662', 'hakdog...', '2024-05-03');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `number` int(10) NOT NULL,
  `message` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `content`
--

CREATE TABLE `content` (
  `id` varchar(20) NOT NULL,
  `tutor_id` varchar(20) NOT NULL,
  `course_id` varchar(20) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `file` varchar(100) NOT NULL,
  `thumb` varchar(100) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp(),
  `status` varchar(20) NOT NULL DEFAULT 'deactive'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `content`
--

INSERT INTO `content` (`id`, `tutor_id`, `course_id`, `title`, `description`, `file`, `thumb`, `date`, `status`) VALUES
('662da0016018d', '662d9ed886885', '662d9f22ebcfe', 'Lesson 1 - Introduction to HTML', ' HTML is the standard markup language for creating Web pages.', '662da001601ab.pdf', '662da001601a6.png', '2024-04-28', 'active'),
('662da86a8e2e6', 'nXsh5IHnMeP1XTq2sSm1', '662da2e82ee0a', 'Lesson 1 - Introduction to CSS', 'CSS is a language used for describing the presentation of a document written in markup languages like HTML.', '662da86a8e306.pdf', '662da86a8e301.png', '2024-04-28', 'active'),
('6633d160a7a9e', '6633', '6633b8ded58dc', 'Math', 'asdas', '6633d160a7ae0.pdf', '6633d160a7ad5.jpg', '2024-05-03', 'active'),
('663452b8c0d0d', '6633', '66344e70a236e', 'yokk', 'dasdasd', '663452b8c0d3d.pdf', '663452b8c0d37.png', '2024-05-03', 'active'),
('6634557ea9efd', '662', '6634552e854c2', 'HTML module', 'asdasd', '6634557ea9f34.pdf', '6634557ea9f28.jpg', '2024-05-03', 'active'),
('663455edad6ad', '662', '663455452b8b9', 'CSS module', 'asdad', '663455edad6c8.pdf', '663455edad6c4.png', '2024-05-03', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `id` varchar(20) NOT NULL,
  `tutor_id` varchar(20) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `thumb` varchar(100) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp(),
  `status` varchar(20) NOT NULL DEFAULT 'deactive'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`id`, `tutor_id`, `title`, `description`, `thumb`, `date`, `status`) VALUES
('6633b8ded58dc', '6633', '1123', 'asd', '6633b8ded5909.png', '2024-05-03', 'active'),
('6633c288e8217', '6635', 'qwe', 'qweqwe', '6633c288e824d.png', '2024-05-03', 'active'),
('6633c50ae6779', '6635', 'asdasd', 'asdasd', '6633c50ae67d7.jpg', '2024-05-03', 'active'),
('66344e70a236e', '6633', 'trial', 'error handling', '66344e70a2391.jpg', '2024-05-03', 'active'),
('6634552e854c2', '662', 'HTML', 'Module', '6634552e854d0.jpg', '2024-05-03', 'active'),
('663455452b8b9', '662', 'CSS', 'Module for CSS', '663455452b8da.jpg', '2024-05-03', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `likes`
--

CREATE TABLE `likes` (
  `user_id` varchar(20) NOT NULL,
  `tutor_id` varchar(20) NOT NULL,
  `content_id` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `likes`
--

INSERT INTO `likes` (`user_id`, `tutor_id`, `content_id`) VALUES
('662da085f420d', '662d9ed886885', '662da0016018d'),
('6633', '6633', '6633d160a7a9e'),
('6633', 'nXsh5IHnMeP1XTq2sSm1', '662da86a8e2e6'),
('6633', '6633', '663452b8c0d0d'),
('6633', '662', '6634557ea9efd'),
('6633', '662', '663455edad6ad');

-- --------------------------------------------------------

--
-- Table structure for table `login_logs`
--

CREATE TABLE `login_logs` (
  `log_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `login_time` datetime DEFAULT NULL,
  `logout_datetime` datetime DEFAULT NULL,
  `token` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login_logs`
--

INSERT INTO `login_logs` (`log_id`, `user_id`, `login_time`, `logout_datetime`, `token`) VALUES
(8, 662, '2024-05-02 11:04:16', '2024-05-02 11:04:32', '663357107515b'),
(9, 662, '2024-05-02 11:05:45', '2024-05-02 11:52:05', '66335769aec35'),
(10, 662, '2024-05-02 12:06:06', NULL, '6633658ed9eb6'),
(11, 6633, '2024-05-02 19:07:01', '2024-05-02 19:08:17', '6633c835118ae'),
(12, 6633, '2024-05-02 19:10:20', NULL, '6633c8fcd0d08'),
(13, 6633, '2024-05-03 04:12:24', NULL, '6634480851f76');

-- --------------------------------------------------------

--
-- Table structure for table `schedule_list`
--

CREATE TABLE `schedule_list` (
  `id` int(30) NOT NULL,
  `user_ID` int(11) NOT NULL,
  `title` text NOT NULL,
  `description` text NOT NULL,
  `start_datetime` datetime NOT NULL,
  `end_datetime` datetime DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0 COMMENT '0=Pending, 1=Approved,2=Declined',
  `date_created` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `schedule_list`
--

INSERT INTO `schedule_list` (`id`, `user_ID`, `title`, `description`, `start_datetime`, `end_datetime`, `status`, `date_created`) VALUES
(11, 662, 'fds', 'fds', '2024-05-03 04:44:00', '2024-05-04 04:44:00', 2, '2024-05-01 20:44:17'),
(12, 662, 'sample', 'dsad', '2024-05-15 14:42:00', '2024-05-18 14:42:00', 1, '2024-05-02 06:43:00'),
(13, 6633, 'hello ', 'papabunot', '2024-05-03 01:05:00', '2024-05-10 14:10:00', 1, '2024-05-02 17:05:39');

-- --------------------------------------------------------

--
-- Table structure for table `tutors`
--

CREATE TABLE `tutors` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `profession` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tutors`
--

INSERT INTO `tutors` (`id`, `name`, `profession`, `email`, `password`, `image`) VALUES
(1, 'aj', 'developer', 'aj@gmail.com', 'f865b53623b121fd34ee5426c792e5c33af8c227', 'oOen9Jchqr2w6RehqYcY.jpg'),
(662, 'julienne mercado', 'teacher', 'aj123@gmail.com', '905417d02acee789c37eb06ce513fec0ab6915a7', '662d9ed8881c4.jpg'),
(6633, 'adrian', 'teacher', 'johnadrian.perce@gma', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', '6633b8c774158.png'),
(6634, 'kobeni', 'teacher', '12313@gmail.com', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', '6633c24abb0bf.png'),
(6635, 'mafe', 'teacher', 'adrian@gmail.com', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', '6633c26d2352a.png');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `image` varchar(100) NOT NULL,
  `sr_code` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `image`, `sr_code`) VALUES
(662, 'juls mercado', 'juls123@gmail.com', 'f865b53623b121fd34ee5426c792e5c33af8c227', '662da085f4227.jpg', '22-44556'),
(6633, 'adrian', 'johnadrian.perce@gma', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', '6633b910a4a3c.png', '22-36813');

-- --------------------------------------------------------

--
-- Table structure for table `viewed_courses`
--

CREATE TABLE `viewed_courses` (
  `view_ID` int(11) NOT NULL,
  `user_ID` int(11) NOT NULL,
  `course_ID` varchar(255) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `viewed_courses`
--

INSERT INTO `viewed_courses` (`view_ID`, `user_ID`, `course_ID`, `date_created`) VALUES
(1, 662, '662', '2024-05-02 09:22:50'),
(2, 662, '662', '2024-05-02 09:23:46'),
(3, 662, '662d9f22ebcfe', '2024-05-02 09:24:15'),
(4, 662, '662d9f22ebcfe', '2024-05-02 09:24:52'),
(5, 662, '662da2e82ee0a', '2024-05-02 09:47:36'),
(6, 6633, '662da2e82ee0a', '2024-05-02 16:18:59'),
(7, 6633, '662da2e82ee0a', '2024-05-02 16:32:39'),
(8, 6633, '662d9f22ebcfe', '2024-05-02 16:33:26'),
(9, 6633, '6633c288e8217', '2024-05-02 16:43:23'),
(10, 6633, '6633c50ae6779', '2024-05-02 16:53:50'),
(11, 6633, '662d9f22ebcfe', '2024-05-02 17:00:43'),
(12, 6633, '6633c288e8217', '2024-05-02 17:02:32'),
(13, 6633, '6633c288e8217', '2024-05-02 17:07:25'),
(14, 6633, '6633c288e8217', '2024-05-02 17:07:50'),
(15, 6633, '662d9f22ebcfe', '2024-05-02 17:12:09'),
(16, 6633, '662da2e82ee0a', '2024-05-02 17:12:32'),
(17, 6633, '662da2e82ee0a', '2024-05-02 17:12:43'),
(18, 6633, '662da2e82ee0a', '2024-05-02 17:17:05'),
(19, 6633, '662da2e82ee0a', '2024-05-02 17:17:07'),
(20, 6633, '662da2e82ee0a', '2024-05-02 17:17:08'),
(21, 6633, '662da2e82ee0a', '2024-05-02 17:17:08'),
(22, 6633, '662da2e82ee0a', '2024-05-02 17:17:08'),
(23, 6633, '662da2e82ee0a', '2024-05-02 17:17:08'),
(24, 6633, '662da2e82ee0a', '2024-05-02 17:17:08'),
(25, 6633, '662da2e82ee0a', '2024-05-02 17:17:08'),
(26, 6633, '662da2e82ee0a', '2024-05-02 17:17:30'),
(27, 6633, '662da2e82ee0a', '2024-05-02 17:18:45'),
(28, 6633, '662da2e82ee0a', '2024-05-02 17:19:02'),
(29, 6633, '662da2e82ee0a', '2024-05-02 17:24:48'),
(30, 6633, '662da2e82ee0a', '2024-05-02 17:25:32'),
(31, 6633, '662d9f22ebcfe', '2024-05-02 17:25:54'),
(32, 6633, '6633b8ded58dc', '2024-05-02 17:25:58'),
(33, 6633, '6633c288e8217', '2024-05-02 17:26:02'),
(34, 6633, '6633c50ae6779', '2024-05-02 17:26:04'),
(35, 6633, '662da2e82ee0a', '2024-05-02 17:26:08'),
(36, 6633, '662da2e82ee0a', '2024-05-02 17:27:38'),
(37, 6633, '662da2e82ee0a', '2024-05-02 17:30:13'),
(38, 6633, '662da2e82ee0a', '2024-05-02 17:32:39'),
(39, 6633, '662da2e82ee0a', '2024-05-02 17:35:38'),
(40, 6633, '662da2e82ee0a', '2024-05-02 17:35:39'),
(41, 6633, '662da2e82ee0a', '2024-05-02 17:35:39'),
(42, 6633, '662da2e82ee0a', '2024-05-02 17:35:39'),
(43, 6633, '662da2e82ee0a', '2024-05-02 17:35:40'),
(44, 6633, '662da2e82ee0a', '2024-05-02 17:35:40'),
(45, 6633, '662da2e82ee0a', '2024-05-02 17:35:40'),
(46, 6633, '662da2e82ee0a', '2024-05-02 17:35:40'),
(47, 6633, '662da2e82ee0a', '2024-05-02 17:35:40'),
(48, 6633, '662da2e82ee0a', '2024-05-02 17:35:41'),
(49, 6633, '662d9f22ebcfe', '2024-05-02 17:35:46'),
(50, 6633, '6633c288e8217', '2024-05-02 17:35:56'),
(51, 6633, '662da2e82ee0a', '2024-05-02 17:37:25'),
(52, 6633, '662da2e82ee0a', '2024-05-02 17:37:26'),
(53, 6633, '662da2e82ee0a', '2024-05-02 17:37:27'),
(54, 6633, '662da2e82ee0a', '2024-05-02 17:37:27'),
(55, 6633, '662da2e82ee0a', '2024-05-02 17:37:27'),
(56, 6633, '662da2e82ee0a', '2024-05-02 17:38:01'),
(57, 6633, '662da2e82ee0a', '2024-05-02 17:41:07'),
(58, 6633, '662da2e82ee0a', '2024-05-02 17:41:08'),
(59, 6633, '662da2e82ee0a', '2024-05-02 17:41:13'),
(60, 6633, '662da2e82ee0a', '2024-05-02 17:42:38'),
(61, 6633, '662da2e82ee0a', '2024-05-02 17:42:38'),
(62, 6633, '662da2e82ee0a', '2024-05-02 17:42:38'),
(63, 6633, '662da2e82ee0a', '2024-05-02 17:42:39'),
(64, 6633, '662da2e82ee0a', '2024-05-02 17:42:39'),
(65, 6633, '662da2e82ee0a', '2024-05-02 17:42:39'),
(66, 6633, '662da2e82ee0a', '2024-05-02 17:42:39'),
(67, 6633, '662da2e82ee0a', '2024-05-02 17:42:39'),
(68, 6633, '662da2e82ee0a', '2024-05-02 17:42:39'),
(69, 6633, '662da2e82ee0a', '2024-05-02 17:42:55'),
(70, 6633, '662da2e82ee0a', '2024-05-02 17:43:41'),
(71, 6633, '662da2e82ee0a', '2024-05-02 17:43:42'),
(72, 6633, '662da2e82ee0a', '2024-05-02 17:43:44'),
(73, 6633, '662da2e82ee0a', '2024-05-02 17:43:45'),
(74, 6633, '6633b8ded58dc', '2024-05-02 17:43:57'),
(75, 6633, '6633b8ded58dc', '2024-05-02 17:43:59'),
(76, 6633, '6633b8ded58dc', '2024-05-02 17:44:05'),
(77, 6633, '6633b8ded58dc', '2024-05-02 17:45:31'),
(78, 6633, '6633b8ded58dc', '2024-05-02 17:46:17'),
(79, 6633, '6633b8ded58dc', '2024-05-02 17:48:32'),
(80, 6633, '6633b8ded58dc', '2024-05-02 17:48:33'),
(81, 6633, '662da2e82ee0a', '2024-05-02 18:04:51'),
(82, 6633, '662da2e82ee0a', '2024-05-03 02:12:56'),
(83, 6633, '662da2e82ee0a', '2024-05-03 02:16:12'),
(84, 6633, '662da2e82ee0a', '2024-05-03 02:16:24'),
(85, 6633, '662da2e82ee0a', '2024-05-03 02:16:30'),
(86, 6633, '662da2e82ee0a', '2024-05-03 02:16:30'),
(87, 6633, '662da2e82ee0a', '2024-05-03 02:16:33'),
(88, 6633, '662da2e82ee0a', '2024-05-03 02:18:25'),
(89, 6633, '662da2e82ee0a', '2024-05-03 02:19:16'),
(90, 6633, '662d9f22ebcfe', '2024-05-03 02:19:26'),
(91, 6633, '6633b8ded58dc', '2024-05-03 02:19:32'),
(92, 6633, '662da2e82ee0a', '2024-05-03 02:20:23'),
(93, 6633, '662da2e82ee0a', '2024-05-03 02:27:27'),
(94, 6633, '662da2e82ee0a', '2024-05-03 02:27:54'),
(95, 6633, '662da2e82ee0a', '2024-05-03 02:28:11'),
(96, 6633, '662da2e82ee0a', '2024-05-03 02:29:04'),
(97, 6633, '66344e70a236e', '2024-05-03 02:42:40'),
(98, 6633, '66344e7e8ba44', '2024-05-03 02:42:47'),
(99, 6633, '662d9f22ebcfe', '2024-05-03 02:42:55'),
(100, 6633, '6633c288e8217', '2024-05-03 02:43:02'),
(101, 6633, '6633b8ded58dc', '2024-05-03 02:43:06'),
(102, 6633, '6633c50ae6779', '2024-05-03 02:43:14'),
(103, 6633, '662da2e82ee0a', '2024-05-03 02:43:18'),
(104, 6633, '66344e70a236e', '2024-05-03 02:58:17'),
(105, 6633, '66344e70a236e', '2024-05-03 02:59:48'),
(106, 6633, '66344e70a236e', '2024-05-03 02:59:51'),
(107, 6633, '662d9f22ebcfe', '2024-05-03 03:03:59'),
(108, 6633, '662da2e82ee0a', '2024-05-03 03:04:11'),
(109, 6633, '662d9f22ebcfe', '2024-05-03 03:04:51'),
(110, 6633, '6634552e854c2', '2024-05-03 03:10:23'),
(111, 6633, '6634552e854c2', '2024-05-03 03:10:56'),
(112, 6633, '6634552e854c2', '2024-05-03 03:10:57'),
(113, 6633, '663455452b8b9', '2024-05-03 03:11:02'),
(114, 6633, '663455452b8b9', '2024-05-03 03:11:04'),
(115, 6633, '663455452b8b9', '2024-05-03 03:11:51'),
(116, 6633, '663455452b8b9', '2024-05-03 03:15:03');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `login_logs`
--
ALTER TABLE `login_logs`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `schedule_list`
--
ALTER TABLE `schedule_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tutors`
--
ALTER TABLE `tutors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `viewed_courses`
--
ALTER TABLE `viewed_courses`
  ADD PRIMARY KEY (`view_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `login_logs`
--
ALTER TABLE `login_logs`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `schedule_list`
--
ALTER TABLE `schedule_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tutors`
--
ALTER TABLE `tutors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6636;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6634;

--
-- AUTO_INCREMENT for table `viewed_courses`
--
ALTER TABLE `viewed_courses`
  MODIFY `view_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=117;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `login_logs`
--
ALTER TABLE `login_logs`
  ADD CONSTRAINT `login_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
