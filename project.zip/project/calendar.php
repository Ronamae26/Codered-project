<?php
   include 'components/connect.php';
   if(isset($_COOKIE['user_id'])){
      $user_id = $_COOKIE['user_id'];
   } else {
      $user_id = '';
   }
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>courses</title>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
   <link rel="stylesheet" href="css/style.css">
   <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="fullcalendar/lib/main.min.css">
    <script src="js/jquery-3.6.0.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="fullcalendar/lib/main.min.js"></script>
    <style>
        :root {
            --bs-success-rgb: 71, 222, 152 !important;
        }

        html,
        body {
            height: 100%;
            width: 100%;
            font-family: Apple Chancery, cursive;
        }

        .btn-info.text-light:hover,
        .btn-info.text-light:focus {
            background: #000;
        }
        table, tbody, td, tfoot, th, thead, tr {
            border-color: #ededed !important;
            border-style: solid;
            border-width: 1px !important;
        }
        .fc button {
           background-color: #dc3545 !important;
           border-color: #dc3545 !important;
        }
         .fc h2 {
             font-size: 24px;
         }

         .fc th {
             font-size: 18px;
         }

         .fc td, .fc th {
             padding: 10px;
             font-size: 16px;
         }

         .fc-event-title {
             font-size: 16px;
         }

         .fc-daygrid-event {
             font-size: 16px;
         }
         .side-bar .navbar a {
             padding: 10px 28px; 
             text-decoration: none;
         }
    </style>
</head>
<body>

<?php include 'components/user_header.php'; ?>

<section class="courses">
   <h1 class="heading">All Appointments</h1>
      <div class="container" id="page-container">
        <div class="row">
            <div class="col-md-8">
                <div id="calendar"></div>
            </div>
            <div class="col-md-4">
                <div class="cardt rounded-0 shadow">
                    <div class="card-header bg-gradient bg-danger text-light">
                        <h5 class="card-title">Schedule Form </h5>
                    </div>
                    <div class="card-body" style="font-size: 17px;">
                        <div class="container-fluid">
                            <form action="save_schedule.php" method="post" id="schedule-form">
                                <input type="hidden" name="user_ID" value="<?= $user_id ?>">
                                <input type="hidden" name="id" value="">
                                <div class="form-group mb-4">
                                    <label for="title" class="control-label">Title</label>
                                    <input type="text" class="form-control form-control-sm rounded-0" name="title" id="title" required  style="font-size: 17px;">
                                </div>
                                <div class="form-group mb-4">
                                    <label for="description" class="control-label">Description</label>
                                    <textarea rows="3" class="form-control form-control-sm rounded-0" name="description" id="description" required  style="font-size: 17px;"></textarea>
                                </div>
                                <div class="form-group mb-4">
                                    <label for="start_datetime" class="control-label">Start</label>
                                    <input type="datetime-local" class="form-control form-control-sm rounded-0" name="start_datetime" id="start_datetime" required  style="font-size: 17px;">
                                </div>
                                <div class="form-group mb-4">
                                    <label for="end_datetime" class="control-label">End</label>
                                    <input type="datetime-local" class="form-control form-control-sm rounded-0" name="end_datetime" id="end_datetime" required  style="font-size: 17px;">
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="card-footer">
                        <div class="text-center">
                            <button class="btn btn-danger rounded-0" type="submit" form="schedule-form"  style="font-size: 17px;"><i class="fa fa-save"></i> Save</button>
                            <button class="btn btn-default border rounded-0" type="reset" form="schedule-form"  style="font-size: 17px;"><i class="fa fa-reset"></i> Cancel</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Event Details Modal -->
    <div class="modal fade" tabindex="-1" data-bs-backdrop="static" id="event-details-modal">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content rounded-0">
                <div class="modal-header rounded-0">
                    <h2 class="modal-title">Schedule Details</h2>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body rounded-0">
                    <div class="container-fluid" style="font-size: 15px;">
                        <dl>
                            <dt class="text-muted">Title</dt>
                            <dd id="title" class="fw-bold fs-4"></dd>
                            <dt class="text-muted">Description</dt>
                            <dd id="description" class=""></dd>
                            <dt class="text-muted">Start</dt>
                            <dd id="start" class=""></dd>
                            <dt class="text-muted">End</dt>
                            <dd id="end" class=""></dd>
                        </dl>
                    </div>
                </div>
                <div class="modal-footer rounded-0">
                    <div class="text-end d-flex">
                        <button type="button" class="btn m-1 btn-primary rounded-0" id="edit" data-id="" style="font-size: 17px;">Edit</button>
                        <button type="button" class="btn m-1 btn-danger rounded-0" id="delete" data-id="" style="font-size: 17px;">Delete</button>
                        <button type="button" class="btn m-1 btn-secondary rounded-0" data-bs-dismiss="modal" style="font-size: 17px;">Close</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<?php 
   $schedules = $conn->query("SELECT * FROM `schedule_list`");
   $sched_res = [];
   while ($row = $schedules->fetch(PDO::FETCH_ASSOC)) {
       $row['sdate'] = date("F d, Y h:i A", strtotime($row['start_datetime']));
       $row['edate'] = date("F d, Y h:i A", strtotime($row['end_datetime']));
       $sched_res[$row['id']] = $row;
   }
   if(isset($conn)) $conn = null;
?>

<script src="js/script2.js"></script>
<script src="js/script.js"></script>
<script>
    var scheds = $.parseJSON('<?= json_encode($sched_res) ?>')
</script> 
</body>
</html>