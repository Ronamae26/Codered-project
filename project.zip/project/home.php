<?php

include 'components/connect.php';

if(isset($_COOKIE['user_id'])){
   $user_id = $_COOKIE['user_id'];
}else{
   $user_id = '';
}

$select_likes = $conn->prepare("SELECT * FROM `likes` WHERE user_id = ?");
$select_likes->execute([$user_id]);
$total_likes = $select_likes->rowCount();

$select_comments = $conn->prepare("SELECT * FROM `comments` WHERE user_id = ?");
$select_comments->execute([$user_id]);
$total_comments = $select_comments->rowCount();

$select_bookmark = $conn->prepare("SELECT * FROM `bookmark` WHERE user_id = ?");
$select_bookmark->execute([$user_id]);
$total_bookmarked = $select_bookmark->rowCount();

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>home</title>

 
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

   <link rel="stylesheet" href="css/style.css">
   <link rel="stylesheet" href="https://cdn.datatables.net/2.0.5/css/dataTables.dataTables.css">
   <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
   <script src="https://cdn.datatables.net/2.0.5/js/dataTables.js"></script>
   <style>
      .login-history-table {
          width: 100%;
          border-collapse: collapse;
      }

      .login-history-table th {
          background-color: #f8f9fa;
          border: 1px solid #dee2e6; 
          padding: 8px;
          text-align: left;
      }

      .login-history-table td {
          border: 1px solid #dee2e6;
          padding: 8px;
      }

      .login-history-table tbody tr:nth-child(even) {
          background-color: #f8f9fa;
      }

      .login-history-table .empty {
          text-align: center;
          padding: 10px;
          color: #6c757d;
      }

      .login-history-table th,
      .login-history-table td {
          font-size: 16px;
      }

      .search-input {
          margin-bottom: 10px;
          padding: 8px;
          width: 100%;
          box-sizing: border-box;
          border: 1px solid #ced4da;
          border-radius: 4px;
          font-size: 16px;
      }

      .match {
          background-color: yellow;
      }

   </style>
</head>
<body>

<?php include 'components/user_header.php'; ?>



<section class="quick-select">

   <h1 class="heading">quick options</h1>

   <div class="box-container">

      <?php
         if($user_id != ''){
      ?>
      <div class="box">
         <h3 class="title">likes and comments</h3>
         <p>total likes : <span><?= $total_likes; ?></span></p>
         <a href="likes.php" class="inline-btn">view likes</a>
         <p>total comments : <span><?= $total_comments; ?></span></p>
         <a href="comments.php" class="inline-btn">view comments</a>
         <p>saved course : <span><?= $total_bookmarked; ?></span></p>
         <a href="bookmark.php" class="inline-btn">view bookmark</a>
      </div>
      <?php
         }else{ 
      ?>

      <?php
      }
      ?>

      <div class="box">
         <h3 class="title">Appointments</h3>
         <div class="flex">
            <table id="example" class="display login-history-table" style="width:100%">
               <thead>
                  <tr>
                     <th>Appt title</th>
                     <th>Status</th>
                  </tr>
               </thead>
               <tbody>
                  <?php
                     $i = 1;
                     $select_logs = $conn->query("SELECT * FROM schedule_list JOIN users ON schedule_list.user_ID = users.id WHERE schedule_list.user_ID=$user_id ORDER BY schedule_list.id DESC");
                     while($fetch_log = $select_logs->fetch(PDO::FETCH_ASSOC)){
                            
                  ?>
                  <tr>
                     <td><?= $fetch_log['title']; ?></td>
                     <td>
                        <?php if($fetch_log['status'] == 0): ?>
                           <span class="badge bg-danger">Pending</span>
                        <?php elseif($fetch_log['status'] == 1): ?>
                           <span class="badge bg-success">Approved</span>
                        <?php elseif($fetch_log['status'] == 2): ?>
                           <span class="badge bg-success">Declined</span>
                        <?php else: ?>
                           <span class="badge bg-dark">Unknown status</span>
                        <?php endif; ?>
                     </td>
                  </tr>
                  <?php
                        }
                  ?>
               </tbody>
            </table>
         </div>
      </div>

      <div class="box">
         <h3 class="title">popular topics</h3>
         <div class="flex">
            <a href="#"><i class="fab fa-html5"></i><span>HTML</span></a>
            <a href="#"><i class="fab fa-css3"></i><span>CSS</span></a>
            <a href="#"><i class="fab fa-js"></i><span>javascript</span></a>
            <a href="#"><i class="fab fa-react"></i><span>react</span></a>
            <a href="#"><i class="fab fa-php"></i><span>PHP</span></a>
            <a href="#"><i class="fab fa-bootstrap"></i><span>bootstrap</span></a>
         </div>
      </div>

   </div>

</section>



<section class="courses">

   <h1 class="heading">latest courses</h1>

   <div class="box-container">

      <?php
         $select_courses = $conn->prepare("SELECT * FROM `course` WHERE status = ? ORDER BY date DESC LIMIT 6");
         $select_courses->execute(['active']);
         if($select_courses->rowCount() > 0){
            while($fetch_course = $select_courses->fetch(PDO::FETCH_ASSOC)){
               $course_id = $fetch_course['id'];

               $select_tutor = $conn->prepare("SELECT * FROM `tutors` WHERE id = ?");
               if (!$select_tutor) {
                  die('Error preparing statement: ' . $conn->errorInfo()[2]);
              }
               $select_tutor->execute([$fetch_course['tutor_id']]);
               if ($select_tutor->rowCount() > 0) {
               $fetch_tutor = $select_tutor->fetch(PDO::FETCH_ASSOC);}
      ?>
      <div class="box">
         <div class="tutor">
            <img src="uploaded_files/<?= $fetch_tutor['image']; ?>" alt="">
            <div>
               <h3><?= $fetch_tutor['name']; ?></h3>
               <span><?= $fetch_course['date']; ?></span>
            </div>
         </div>
         <img src="uploaded_files/<?= $fetch_course['thumb']; ?>" class="thumb" alt="">
         <h3 class="title"><?= $fetch_course['title']; ?></h3>
         <a href="courses.php?get_id=<?= $course_id; ?>" class="inline-btn">view course</a>
      </div>
      <?php
         }
      }else{
         echo '<p class="empty">no courses added yet!</p>';
      }
      ?>

   </div>

   <div class="more-btn">
      <a href="courses.php" class="inline-option-btn">view more</a>
   </div>

</section>


<script src="js/script.js"></script>
   <script>
   new DataTable('#example', {
    layout: {
        bottomEnd: {
            paging: {
                boundaryNumbers: false
            }
        }
    }
});
</script>
</body>
</html>