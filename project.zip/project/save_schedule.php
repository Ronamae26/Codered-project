<?php 
include 'components/connect.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] != 'POST') {
    echo "<script> alert('Error: No data to save.'); location.replace('./') </script>";
    $conn = null;
    exit;
}

extract($_POST);
$allday = isset($allday);

// Extract the date part from the start_datetime
$start_date = date('Y-m-d', strtotime($start_datetime));
$date_today = date('Y-m-d');

// Count the number of appointments for the given day
$count_sql = "SELECT COUNT(*) AS appointment_count FROM `schedule_list` WHERE DATE(date_created) = '$date_today'";
$count_result = $conn->query($count_sql);
$appointment_count = $count_result->fetch(PDO::FETCH_ASSOC)['appointment_count'];

// Check if the number of appointments exceeds 8
if ($appointment_count >= 8) {
    echo "<script> alert('Error: You can only have 8 appointments per day.'); location.replace('./') </script>";
    $conn = null;
    exit;
}

// If the appointment count is less than 8, proceed with insertion or update
if (empty($id)) {
    $sql = "INSERT INTO `schedule_list` (`user_ID`, `title`, `description`, `start_datetime`, `end_datetime`) VALUES ('$user_ID', '$title', '$description', '$start_datetime', '$end_datetime')";
} else {
    $sql = "UPDATE `schedule_list` SET `title` = '{$title}', `description` = '{$description}', `start_datetime` = '{$start_datetime}', `end_datetime` = '{$end_datetime}' WHERE `id` = '{$id}'";
}

$save = $conn->query($sql);
if ($save) {
    echo "<script> alert('Schedule Successfully Saved.'); location.replace('calendar.php') </script>";
} else {
    echo "<pre>";
    echo "An Error occurred.<br>";
    echo "Error: ".$conn->error."<br>";
    echo "SQL: ".$sql."<br>";
    echo "</pre>";
}

$conn = null;
?>
