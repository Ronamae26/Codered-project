<?php

include 'components/connect.php';

if(isset($_COOKIE['user_id'])){
   $user_id = $_COOKIE['user_id'];
}else{
   $user_id = '';
}

// ORIGINAL CODE
// if(isset($_POST['submit'])){
//    $sr_code = $_POST['sr_code']; 
//    $sr_code = filter_var($sr_code, FILTER_SANITIZE_STRING); 
//    $pass = sha1($_POST['pass']);
//    $pass = filter_var($pass, FILTER_SANITIZE_STRING);

//    $select_user = $conn->prepare("SELECT * FROM `users` WHERE sr_code = ? AND password = ? LIMIT 1"); // Changed from email to sr_code
//    $select_user->execute([$sr_code, $pass]);
//    $row = $select_user->fetch(PDO::FETCH_ASSOC);
   
//    if($select_user->rowCount() > 0){
//      setcookie('user_id', $row['id'], time() + 60*60*24*30, '/');
//      header('location:home.php');
//    }else{
//       $message[] = 'Incorrect sr-code or password!'; 
//    }
// }
if(isset($_POST['submit'])){

   $sr_code = $_POST['sr_code']; 
   $sr_code = filter_var($sr_code, FILTER_SANITIZE_STRING); 
   $pass = sha1($_POST['pass']);
   $pass = filter_var($pass, FILTER_SANITIZE_STRING);



   $select_user = $conn->prepare("SELECT * FROM `users` WHERE sr_code = ? AND password = ? LIMIT 1");
   $select_user->execute([$sr_code, $pass]);
   $row = $select_user->fetch(PDO::FETCH_ASSOC);
   
   if($select_user->rowCount() > 0){
     // Insert login log into database
     $user_id = $row['id'];
     $login_time = date('Y-m-d H:i:s');

     $token = uniqid();

     $insert_log = $conn->prepare("INSERT INTO login_logs (user_id, login_time, token) VALUES (?, ?, ?)");
     $insert_log->execute([$user_id, $login_time, $token]);

     session_start();
     $_SESSION['token'] = $token;

     // Set cookie and redirect
     setcookie('user_id', $user_id, time() + 60*60*24*30, '/');
     header('location:home.php');
   }else{
      $message[] = 'Incorrect sr-code or password!'; 
   }
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Login</title>

   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
   <link rel="stylesheet" href="css/style.css">

</head>
<body>

   <section class="form-container">
      <form action="" method="post" enctype="multipart/form-data" class="login">
      <div style="text-align: center;">
         <img src="images/Web logo.png" alt="Code Red Logo" style="width: 150px; height: 150px;">
      </div>
         <h3>Welcome back!</h3>
         <?php if (!empty($message)) { ?>
            <div class="error-message">
               <?php foreach ($message as $msg) {
                  echo "<p>$msg</p>";
               } ?>
            </div>
         <?php } ?>
         <p>your sr-code <span>*</span></p> 
         <input type="text" name="sr_code" placeholder="enter your sr-code" class="box" pattern="[0-9\-]+" title="Enter a valid sr-code containing numbers and dashes only">
         <p>your password <span>*</span></p> 
         <input type="password" name="pass" placeholder="enter your password" maxlength="20" required class="box"> 
         <p class="link">Don't have an account? <a href="register.php">Register now</a></p>
         <input type="submit" name="submit" value="Login now" class="btn"> 
      </form>
   </section>

<script src="js/script.js"></script>
   
</body>
</html>
